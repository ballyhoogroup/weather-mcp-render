# Changelog

## 0.4.0

- Ported the MCP App lifecycle, metadata, session shape, and UI behavior from the known-working `ballyhoogroup/supportbridge` connector.
- Added the proven `open_support_chat`, `support_get_messages`, `support_send_message`, and `support_end_session` contract.
- Added preferred-frame resource metadata and the working inline display capability handshake.
- Added a compatibility fixture and conformance assertions to prevent drift from the working connector.
- Connected the proven chat lifecycle to the external multi-tenant control plane.

## 0.3.1

- Added a model-visible, MCP-App-linked `talk_to_support` tool.
- Added reopening of an existing ticket by ID so a missing or scrolled-away widget can be rendered again.
- Ensured new and reopened chats return the state required by the embedded app.

## 0.3.0

- Added one-call installation for the official TypeScript MCP SDK.
- Added automatic support-tool, MCP App resource, chat-handler, policy-sync, and shutdown registration.
- Added a single shared identity resolver and automatic recent-tool ticket briefs.
- Added installation capability telemetry, dashboard connection status, and `supportbridge doctor`.

## 0.2.0

- Added a portable MCP App resource for embedded SupportBridge live chat.
- Added ticket creation to `accept_support_offer` when a control-plane client is supplied.
- Added app-only chat refresh and message handlers with a text fallback for non-App hosts.

## 0.1.0

- Added framework-neutral tool-call instrumentation and MCP result adaptation.
- Added sanitized, bounded telemetry with buffered HTTP delivery.
- Added argument-match and repeated-failure support triggers.
- Added blocking support offers with accept, dismiss, and reset state.
- Added optional agent and model spans with async trace propagation.
- Added pluggable telemetry transports and trigger-state stores.
- Added remote policy synchronization and support-chat control-plane client.
- Added a tenant-scoped vendor control plane with Live Streams, Visitor 360, chat, and policy management.
